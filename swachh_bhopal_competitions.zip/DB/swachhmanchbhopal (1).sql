-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2021 at 11:28 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `swachhmanchbhopal`
--

-- --------------------------------------------------------

--
-- Table structure for table `files_uploaded`
--

CREATE TABLE `files_uploaded` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_verify` int(1) DEFAULT NULL,
  `mobile_verify` int(1) DEFAULT NULL,
  `mobile_otp` varchar(10) DEFAULT NULL,
  `usertype` varchar(10) DEFAULT NULL,
  `approval_status` int(1) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `uploaded_on` datetime DEFAULT current_timestamp(),
  `ipaddress` varchar(50) DEFAULT NULL,
  `blowserdetails` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files_uploaded`
--

INSERT INTO `files_uploaded` (`id`, `name`, `mobile`, `address`, `category`, `image`, `email`, `email_verify`, `mobile_verify`, `mobile_otp`, `usertype`, `approval_status`, `password`, `uploaded_on`, `ipaddress`, `blowserdetails`) VALUES
(36, 'ANKIT SHARMA', '8770076126', 'BHOPAL', 'other', '1daa95fbba7a934cb76838c68523c53b.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-09 12:50:52', NULL, NULL),
(41, 'Sheeya saxena ', '8878898999', 'Flat no s-5 2 nd floor shree krishna arcade ', 'other', '9373d8e428de519db2903c6fd2b435ca.jpeg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-09 17:27:06', NULL, NULL),
(42, 'Alpna jha', '9399963809', 'Bharat Nagar house no.4 BHEL bhopal', 'other', '160468eb591d9b3f96b540b5e33ada96.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-09 18:55:25', NULL, NULL),
(48, 'Aditya Tiwari', '8839457488', '30, new friends society,chunnabhatti,Bhopal', 'other', '58df9766e4b2601e9bd07daa793ea258.jpeg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 02:40:48', NULL, NULL),
(49, 'Ankit Sharma', '8770076126', 'Bhopal', 'other', '8441a0df2cbcfe8f8e8d3fa827246cd8.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 08:43:47', NULL, NULL),
(50, 'Ankit Sharma', '8770076126', 'Bhopal', 'other', '85fb4bfc054b96b4a0e4601e63711a4f.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 08:50:39', NULL, NULL),
(51, 'Akshara Kolasani', '9753425845', 'EN 2/8, Char Imli', 'other', '7744cd63657e0a8ae0e3b74e096f195b.jpg', NULL, NULL, 1, NULL, 'user', 1, '202cb962ac59075b964b07152d234b70', '2021-09-10 10:09:46', NULL, NULL),
(53, 'Dinesh More', '9074340931', 'H.No.1166 C/Sector Anna Nagar Govindpura Bhopal', 'other', '3330991bbfc6dab0901043bf91b71c80.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 10:19:07', NULL, NULL),
(55, 'Aksh Thakur', '7000973300', 'D-3/578 Danish nagar Bhopal', 'other', 'f1ce7186d077600d0578c7b8432177b5.jpg', NULL, NULL, 0, NULL, 'user', 1, NULL, '2021-09-10 11:09:49', NULL, NULL),
(56, 'Jai Ambey', '9893851821', 'ews 820 kotra sultanabad', 'other', '4ef0661efe83ebb3152b65ce4abd478f.jpeg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 12:49:03', NULL, NULL),
(57, 'Dr Sheetal Choudhari', '9407486808', 'D25 AMRA Estate Nayapura Kolar Road BHOPAL 462042 MP', 'other', '6dd0d6409c164261b430acd566f00263.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 13:13:00', NULL, NULL),
(59, 'Aksh Thakur', '7000973300', 'Bhopal', 'other', 'a94c41bdbbb2850521f5c97a163fd314.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 13:26:50', NULL, NULL),
(60, 'Dinesh Kumar Lodhi', '9604493614', 'Bhopal', 'other', '68a6354efcb3e00bfa0121ffa60ce6b8.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 13:41:28', NULL, NULL),
(61, 'Naivedya Agrawal ', '7898669666', 'Polytechnic Road Near Petrol Pump bhopal ', 'other', '0d5897a945964f32b2dec0c963a6797a.jpeg', NULL, NULL, NULL, NULL, 'user', 1, 'd41d8cd98f00b204e9800998ecf8427e', '2021-09-10 14:03:39', NULL, NULL),
(62, 'Chandni sarankar ', '7415188102', 'Bhopal', 'other', '14fb6dbf4ee1a2b12726850a0f29a1c7.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 14:54:34', NULL, NULL),
(63, 'Shivani Goutam', '8827325907', 'H 15 THANA T T NAGAR KE AWAS', 'other', '9fe735c822417aedbd29dde0f3fe4324.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 15:13:25', NULL, NULL),
(64, 'Shivani Goutam', '8827325907', 'H 15 THANA T T NAGAR KE AWAS', 'other', '105b03177d56a240a12c07cd1a22f116.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 15:17:53', NULL, NULL),
(65, 'RUCHI JAIN', '8982511035', 'Saket Nagar Bhopal', 'other', 'a9cf6cf20a6a37265c51b3372e60f490.jpeg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 15:26:30', NULL, NULL),
(66, 'RUCHI JAIN', '8982511035', '416 Rachna Nagar Bhopal, Bhopal', 'jhanki', 'ecae8695a3819d87fa9dedc6a392645b.jpeg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 15:27:28', NULL, NULL),
(67, 'Naivedya Agrawal', '9810068784', 'C3/30,Mangal Murti,C/O Dr G.K. Agrawal,Civil lines, Polytechnic Road, Shyamla Hills, Bhopal -462002', 'other', '4a71599ae17359444210654242389cc8.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 15:46:59', NULL, NULL),
(68, 'D Karvade ', '9479356024', '100 c Sector, Shahpura,  Bhopal', 'other', 'ceaf1649620fce282e03aee880050d95.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 16:32:51', NULL, NULL),
(69, 'Pushpendra', '7999733105', '205 awntika homes ankhe di ', 'other', '6ece9264168286011313b1cb56d7e920.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:01:32', NULL, NULL),
(70, 'Pushpendra', '7999733105', '205 awntika homes sankhedi', 'other', '4cb046762fbdf9087d217f3a02a59702.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:06:32', NULL, NULL),
(71, 'Pushpendra', '7999733105', '205 awntika homes sankhedi', 'other', '8f4c06f768a47438e3d9f9c16cc27be5.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:08:39', NULL, NULL),
(72, 'Ankit', '8770076126', 'Bhopal', 'other', '6cc00f9dca9ab6ae28839cfd32cddff9.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:11:55', NULL, NULL),
(73, 'Ankit Shrivastava', '8871759645', 'H.no 65 a sector kaveri colony BEEMA kunj Kolar road Bhopal', 'other', '751f9f119a10d8d17c2d0f6d0148d9e7.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:23:59', NULL, NULL),
(74, 'Ankit Shrivastava', '8871759645', 'H.no 65 a sector kaveri colony BEEMA kunj Kolar road Bhopal', 'other', '69229d037668af87f6ea5e23e3c59adf.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:25:11', NULL, NULL),
(75, 'Vinay Sharma ', '8770987411', '101-2c saket Nagar Bhopal ', 'other', '43781a8c23b9885d00d3e9f1c71d4b1a.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:32:22', NULL, NULL),
(76, 'Ankit Shrivastava', '8871759645', 'H.no 65 a sector kaveri colony BEEMA kunj Kolar road Bhopal', 'other', '663443fed254cf46e4d44412efa3820e.jpg', NULL, NULL, NULL, NULL, 'user', 1, NULL, '2021-09-10 17:36:36', NULL, NULL),
(77, 'Admin Nagar Nigam Bhopal', '9999999999', 'Nagar Nigam Bhopal', NULL, NULL, NULL, NULL, 1, NULL, 'admin', 1, '202cb962ac59075b964b07152d234b70', '2021-09-10 05:09:05', NULL, NULL),
(78, 'Varsha Tiwari', '8319141685', 'Hig 9 shree krishna guru complex sanjeev nagar new jail road bhopal', 'other', '575dbc1452a55160c7f061652ae6fcf0.jpg', NULL, NULL, NULL, NULL, NULL, 1, NULL, '2021-09-10 17:45:41', NULL, NULL),
(84, 'Swanzil Bamaniya', '9713758619', 'HNo. 796 Priyadarshini Nagar Near Narmada Bhawan Bhopal', 'other', '9e30352a46df3617d73173abe52eae34.jpg', 'bunty.bunty.b47@gmail.com', NULL, 1, '775632', 'user', 1, '20a9ded8d9995c8f428fcf84b9649c80', '2021-09-10 19:33:45', NULL, NULL),
(85, 'Sadhana Joshi', '8770875087', '146,Kalpana nagar ,Bhopal', 'other', '7736c0301deabc8f13474c5a2514bce3.jpeg', 'sadhanajoshi131065@gmail.com', NULL, NULL, '538504', 'user', 1, '98e0f858b298f163aa4da1298164b52b', '2021-09-10 19:55:44', NULL, NULL),
(86, 'Deependra Mishra', '9179039563', 'Elixir Garden ', 'other', '2a157198d5c0f7becb4d3702df806ad5.jpg', 'mdeependra1993@gmail.com', NULL, 1, '801147', 'user', 1, '98e3ba1f7091194c5a6b818b4b745c38', '2021-09-10 19:59:47', NULL, NULL),
(87, 'Rashmi Singh ', '9009030903', '6, rishi valley,  vaishali Nagar ', 'other', '814740783d7a1037070a511d7791ad75.jpg', 'apouriyarashmi@gmail.com', NULL, 1, '284332', 'user', 1, '81dc9bdb52d04dc20036dbd8313ed055', '2021-09-10 20:25:11', NULL, NULL),
(88, 'Ankit Shrivastava', '8982177494', 'H.no 65 a sector kaveri colony BEEMA kunj Kolar road Bhopal', 'other', '5d985a68bba0a4376f7e203e02c9d9f3.jpg', 'shrivastava.ankit982@gmail.com', NULL, 1, '665184', 'user', 1, 'b09561f37e457aa6cd3aa05baff54c56', '2021-09-10 20:32:55', NULL, NULL),
(89, 'Anusha Agrawal', '7067593451', '2/2chobdar pura taileya bhopal', 'other', '01e57b0e11f6d0ed265f018aa3df7427.jpg', 'anushaagrawal.2007@gmail.com', NULL, 1, '260651', 'user', 1, '256d412686e9d52e139ebbec3ef3b2c8', '2021-09-10 20:36:52', NULL, NULL),
(90, 'Saksham Agrawal', '9131779492', 'C/o.- Gopal Kale, S-50, Beside Madhuram Sweets, Nehru Nagar, Bhopal (M.P.) Pin No.- 462003', 'other', 'f521aa2669be51d57d94e850863886fc.jpeg', 'sakshambpl2012@gmail.com', NULL, 1, '167555', 'user', 1, 'bd9b62c3b7b504ee630a1570dc2a2acc', '2021-09-10 20:50:28', NULL, NULL),
(91, 'Bharti Ramchandani', '8989405377', 'B-1/402 Green Acre, Lalghati Bhopal', 'other', 'db3cd09868f1b0bb89b3895fd1acb2a4.jpg', 'hk.ramchandani@gmail.com', NULL, NULL, '827929', 'user', 1, '7c53261cc17b8bfe1c0a87a4250a5a8f', '2021-09-10 20:50:51', NULL, NULL),
(92, 'Dr kavita paraste', '7489836707', 'Coral casa bunglow near people\'s mall bhopal', 'other', 'a3ee23605341993eaf1108ea97c9f512.jpg', 'kavitaparaste01@gmail.com', NULL, 1, '273510', 'user', 1, 'e10adc3949ba59abbe56e057f20f883e', '2021-09-10 20:56:25', NULL, NULL),
(93, 'Anshika Sinha', '7879137035', 'Coral Casa Bungalow D-238 ,Behind Best Price , Karond', 'other', '09fb523fcfed74f89b512d67d416e73a.jpg', 'anshikasinha84@gmail.com', NULL, 1, '549125', 'user', 1, '1d2c2cd5b9d5c966951117747a1e680e', '2021-09-10 21:05:42', NULL, NULL),
(94, 'Aarti Raigar', '9179109900', 'B-6 Aamra Eden Park Kolar Road Bhopal', 'jhanki', '01a4ffc3998d9169f4ce987497a80840.jpg', 'mailtoaartiraigar@gmail.com', NULL, 1, '241720', 'user', 1, '88e76c11545d41a9087351183bb52980', '2021-09-10 21:48:12', NULL, NULL),
(95, 'Manoj Joshi', '9977008211', '201, Khushi Apartment, Block A, Behind Danish Kunj Jain Mandir, Kolar Road Bhopal', 'jhanki', '56f0a043bd143eafe007f08979696cf0.jpg', 'manojjoshi6970@gmail.com', NULL, NULL, '266788', 'user', 1, '6d47b5e3ae687ffa137c0b794d8970b3', '2021-09-10 22:20:00', NULL, NULL),
(96, 'Manoj Joshi', '9340931043', '201, Khushi Apartment, Block A, Behind Danish Kunj Jain Mandir, Kolar Road Bhopal', 'other', '988f1b9ce689bab374f0035852e4b535.jpeg', 'manojjoshi6970@gmail.com', NULL, 1, '145962', 'user', 1, '202cb962ac59075b964b07152d234b70', '2021-09-10 22:23:56', NULL, NULL),
(97, 'Dr Dinesh Choudhari ', '8817167260', 'D25 Amra State Nayapura kolar road Bhopal MP 462042 ', 'other', 'e9ead34b7f5a874e44a79d18622a6909.jpg', 'drdinessh007@gmail.com', NULL, 1, '835403', 'user', 1, '2beb1ad02ffe276d5f9e2e4314ff6389', '2021-09-10 22:24:24', NULL, NULL),
(98, 'Prarthana mishra', '9424477290', 'A-4, Jai Bhawani phase-2 Rohit Nagar', 'other', 'ff53b3f3955a2b924c7f92c379bed3aa.jpg', 'prarthana3@gmail.com', NULL, NULL, '724652', 'user', 1, '3e8902c08839b5c7e73defca3fe10aab', '2021-09-10 22:34:14', NULL, NULL),
(99, 'Sudhir Guwalani ', '9039867795', 'Plot no 65 a minal bungalow near nagar Nigam water tank Vijay Nagar lalghati Bhopal ', 'other', '0d3eecbd4ecf5e9801d8167c80b056e2.jpg', 'sudhirguwalani19@gmail.com', NULL, 1, '444596', 'user', 1, '52faf87f5e2ed8f87fb960c71caae4a4', '2021-09-10 22:42:06', NULL, NULL),
(100, 'Yogesh khandelwal', '8959771447', 'Ward no-12 new jwala mukhi colony umariya(M.P)', 'other', 'd6940785d5e422a664ad0ff790b869cb.jpg', 'yogeshkhandelwal0001@gmail.com', NULL, 1, '640996', 'user', 1, '7228f762ba983b2aead26b5240048126', '2021-09-10 22:43:38', NULL, NULL),
(101, 'Lakshya verma', '9826286280', 'LIG 49 shankar Nagar Shivaji nagar Bhopal', 'other', '9be7c6456ea160c7ede2aad0dc9d60de.jpg', 'mahendra7ver7bari@gmail.com', NULL, 1, '116648', 'user', 1, 'dc7e067d07ac60d61cf76368924570e8', '2021-09-10 22:49:08', NULL, NULL),
(102, 'Sonika kushwaha', '9685203514', 'H-3 sahayadri parisar phase-2 bhopal', 'jhanki', '30be7cb63d8208e9048d5489c2e48a1f.jpg', 'sonikakushwaha143@gmail.com', NULL, 1, '665936', 'user', 1, 'da73937f46c70adc4c2b0a20e6fef1a0', '2021-09-10 23:04:37', NULL, NULL),
(103, 'Sonika kushwaha', '9755988910', 'H-3 sahayadri parisar phase-2 bhopal', 'jhanki', 'ba99dcecbedea5e3cca853047be996eb.jpg', 'sonikakushwaha143@gmail.com', NULL, 1, '808118', 'user', 1, 'da73937f46c70adc4c2b0a20e6fef1a0', '2021-09-10 23:06:44', NULL, NULL),
(104, 'Sunil Nema', '9406512595', 'Bhopal', 'other', 'a6fa3074049fe06861e804dbedbcd416.jpg', 'sunil.nema7@gmail.com', NULL, 1, '638315', 'user', 1, '519957b5e0d5f0fc02315bb0c0e9ebce', '2021-09-11 00:00:13', NULL, NULL),
(105, 'Sachin Madan', '9826589999', 'C104 New Minal residency jk road Bhopal', 'other', '21f3bac7540a5ccc4d3649915f786949.jpg', 'virajgreenss@gmail.com', NULL, 1, '384256', 'user', 1, 'f04b4ca6af4752d9edca5a2a12e7d3fa', '2021-09-11 00:12:11', NULL, NULL),
(107, 'Koustubh Persai', '8878100027', 'A40 BHEL Sangam Society Bag Sevaniya bhopal', 'other', 'a8ce5177842b997f3b14a759258c3dde.jpg', 'koustubh.p17@gmail.com', NULL, NULL, '866623', 'user', 1, '81dc9bdb52d04dc20036dbd8313ed055', '2021-09-11 10:57:12', NULL, NULL),
(108, 'Koustubh Persai', '8878800027', 'A40 BHEL Sangam Society Bag Sevaniya bhopal', 'other', '563f3a7620b12eb5b06cbde25f5fd939.jpg', 'koustubh.p17@gmail.com', NULL, 1, '721440', 'user', 1, '81dc9bdb52d04dc20036dbd8313ed055', '2021-09-11 10:59:03', NULL, NULL),
(109, 'Shivam Shrivastava', '7470899100', 'Hamidia road 2/9 Patel Nagar colony', 'other', 'c10637d696f1e623c205b021de606d3e.png', 'shivam12345.2019@gmail.com', NULL, NULL, '766895', 'user', 1, '3e771ef924c02cb3e70b11d274278705', '2021-09-11 11:06:47', NULL, NULL),
(110, 'Shivam Shrivastava', '9893846550', 'Hamidia road 2/9 Patel Nagar colony', 'other', '67028c4d2abda7a5412295ea50ec126c.png', 'shivam12345.2019@gmail.com', NULL, NULL, '103504', 'user', 1, '3e771ef924c02cb3e70b11d274278705', '2021-09-11 11:07:50', NULL, NULL),
(111, 'MOHAN L CHOUDHARY', '8770592499', 'Gram Bindhari Post Bandha tehsil mohangarh', 'other', '1aa69bd262df1701662570c050121433.jpg', 'ahirwarml1996@gmail.com', NULL, 1, '461136', 'user', 1, 'b107e9a7ba2cd6d9e878c1a1c277554c', '2021-09-11 11:13:08', NULL, NULL),
(114, 'Vaishali Malviya', '8109468493', 'Sarvdharam B sector Kolar road Bhopal', 'other', '755f377afc571fa7c175be124afd55b6.jpg', 'vaishalimalviya1999@gmail.com', NULL, 1, '842629', 'user', 1, '6c119bd86c9c439d6171e7036e6c8015', '2021-09-11 12:04:49', NULL, NULL),
(115, 'VIJAY KUMAR PATIDAR', '9977555385', '104 B East Kamla Nagar Piplani BHEL Bhopal', 'other', '4366ae3a830e6351917dcb7df44ee613.jpeg', 'cevijay2014@yahoo.in', NULL, 1, '406562', 'user', 1, '0f18a16608a0bc2436e33d3eedc80f2e', '2021-09-11 12:22:18', NULL, NULL),
(116, 'THE KABADIWALA', '9074536338', '3rd Floor Jyoti Cineplex MP NAGAR ZONE 1', 'other', '7ba73cf340c63ae5409a4e09b94c56ba.jpeg', 'vijaypatidar@thekabadiwala.com', NULL, NULL, '111761', 'user', 1, '6821605bc942819466996d35d8696248', '2021-09-11 12:39:26', NULL, NULL),
(117, 'Shivam Shrivastava', '9644696664', 'Hamidia road 2/9 Patel Nagar colony', 'other', '343a13c7fc498fa2cc0dce35c1a60f21.png', 'shivam12345.2019@gmail.com', NULL, 1, '737394', 'user', 1, 'b9651e430fbb0fc4a65fec9936df990e', '2021-09-11 12:40:57', NULL, NULL),
(118, 'THE KABADIWALA', '7697260260', '3rd Floor Jyoti Cineplex MP NAGAR ZONE 1', 'other', '1639d9bd0c41ea78134564d000b68060.jpeg', 'vijaypatidar@thekabadiwala.com', NULL, 1, '152063', 'user', 1, '2735e15845e8e63276608747e85970cf', '2021-09-11 12:43:37', NULL, NULL),
(119, 'Mehek Karara', '9977340413', '211 Sagar Premium Towers 2', 'other', '9ab02bde044b7a81bf587e5941db3d39.jpg', 'parthkarara@gmail.com', NULL, 1, '161604', 'user', 1, 'ea3277f23fbf4786eb5a0118d8d38b47', '2021-09-11 13:58:28', NULL, NULL),
(120, 'Varsha Tiwari', '8319141685', 'Hig 9 shree krishna guru complex sanjeev nagar new jail road bhopal', 'other', '775da297132391854c453a83778f8947.jpg', 'varsha.tiwari808@gmail.com', NULL, 1, '569327', 'user', 1, 'b6f7719c56248e59e1e1fc3797b782c5', '2021-09-11 13:58:53', NULL, NULL),
(123, 'Chandrika rathor ', '9575732327', 'Cinema road shamgarh mandsaur ', 'other', 'd64c992cf00a801015458a52a6ceccdd.jpg', 'rathorchandrika33@gmail.com', NULL, 1, '812471', 'user', 1, 'c701080710d3544d7d24062516d1e7f0', '2021-09-11 16:27:32', NULL, NULL),
(124, 'Narmada Puram Colony', '9755101878', 'Gram Khejda baramad Narmada Puram Colony Bhanpur Bhopal Ward 74', 'pandal', '32b2eaae2f38cc34702c5aaa258ebcdf.jpg', 'rambhopal4@gmail.com', NULL, 1, '124502', 'user', 1, 'c16b20b355bd1574298591671f9614e4', '2021-09-11 16:44:58', NULL, NULL),
(125, 'Vaibhav Dubey', '9522877047', 'Parika phase 2 Chunabhatti', 'pandal', '11ca47f139451eb6a0a74b7aa922aa34.jpeg', 'vd7000@gmail.com', NULL, 1, '170340', 'user', 1, '799c3c392d2c34a5e3331e2adbc6e724', '2021-09-11 16:51:57', NULL, NULL),
(127, 'D K KHARE ', '9425006224', 'D/25,Rishikalp, Ayodhaya Bypass Road Bhopal ', 'other', 'b94f27d42d56d575b8e777a0b531eb3b.jpg', 'khared582@gmail.com', NULL, 1, '202507', 'user', 1, 'aaff273403b44d87244da0b14ea71e0b', '2021-09-11 17:31:21', NULL, NULL),
(128, 'Dinesh Kumar Dhulani', '9039903171', 'Sonagiri A sector sqaure', 'pandal', 'fb506571fc0e3cbd68bccb06d4e235a0.jpg', 'sanidhyasinghh@gmail.com', NULL, NULL, '297809', 'user', 1, 'a019a3f55f14f0b3d7e2e859bcbdb25a', '2021-09-11 17:42:57', NULL, NULL),
(129, 'Dinesh', '9179517670', 'Sector A Sonagiri', 'pandal', '82bd38e3426ee4ae68dba9f6d4563d8b.jpg', 'sanidhyasinghh@gmail.com', NULL, 1, '302602', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-11 17:50:52', NULL, NULL),
(130, 'Devanshu singh', '7974877913', 'Behind Sindhi dharmshala camp umaria', 'other', '991e94ac621f821fc826ecc445e64274.jpg', 'gs6093740@gmail.com', NULL, 1, '926900', 'user', 1, '7ac904f41417863f8743e13422262df8', '2021-09-11 17:53:49', NULL, NULL),
(131, 'Kunal Sharma ', '9826047934', 'Sonagiri Sector B', 'pandal', 'e69ed530105603035d214074cff12274.jpg', 'daryaniprakash@yahoo.com', NULL, 1, '864421', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-11 17:59:15', NULL, NULL),
(132, 'Akshat Narayan Giri', '9131886147', 'Indrapuri', 'other', 'de05b6ef9758cdd7c57c26794f691dcf.jpg', 'akshatgiri007@icloud.com', NULL, 1, '514931', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-11 18:09:36', NULL, NULL),
(133, 'Khushi Dangi', '9826135348', 'H. No. - 5 Bhairopur Misrod Bhopal Madhya Pradesh', 'other', 'ae37597fcf1d6b595d28dc1df15aca8f.jpg', 'khushidangi4121@gmail.com', NULL, 1, '162221', 'user', 1, '973a0d4acaf058af5f8cc738ac876364', '2021-09-11 18:12:52', NULL, NULL),
(134, 'Harsh Dubey', '8251819978', '13/7Ajanta complex, indrapuri, bhopal', 'other', '22939aa9db98331919763facd0b3fbfc.jpg', 'harshdubey42@gmail.com', NULL, 1, '703142', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-11 18:18:35', NULL, NULL),
(135, 'Amit Singh', '8770771141', 'Narela Sankari', 'pandal', 'e58bdc4bbbbbf5db57f1b9a8afc1f662.jpg', 'singhamit49439@gmail.com', NULL, 1, '614261', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-11 18:28:51', NULL, NULL),
(136, 'Rahul singh', '9713413427', '255 n2 c sector berkheda bhel', 'other', '2976a6590dbd3f544a591676961b7227.jpg', 'Rahulsingh14129@gmail.com', NULL, 1, '242235', 'user', 1, '084484c48e521d45b6dac69d88ab0a81', '2021-09-11 19:02:37', NULL, NULL),
(138, 'Bhanu Priya ', '8871803671', 'C sector shahpura  Bhopal', 'other', 'c699f02dd4aa919cc557992c75a6a5b9.jpg', 'bhanu2104priya@gmail.com', NULL, 1, '907910', 'user', 1, '79b2a493edb978485df1ab47ae8e811c', '2021-09-11 19:07:29', NULL, NULL),
(139, 'Manish shrivastava ', '9826284585', 'Ews-445 kotra sultana bad bhopal', 'other', 'c7b8caf66a014a4dabf1e55c0304960f.jpg', 'manishkmc2@gmail.com', NULL, NULL, '756773', 'user', 1, '0ef0ea30915ef80d72539852428c0f39', '2021-09-11 19:27:57', NULL, NULL),
(140, 'Manish shrivastava ', '9826284585', 'Ews-445 kotra sultana bad bhopal', 'other', '01cefd60d3cef4861377e1c8f2659766.jpg', 'manishkmc2@gmail.com', NULL, 1, '852547', 'user', 1, '0ef0ea30915ef80d72539852428c0f39', '2021-09-11 19:28:21', NULL, NULL),
(141, 'Ramchandani ji', '9425079569', 'Royal Market', 'pandal', 'ff27d09bbbfed0c39ef385be494a81e9.jpg', 'pratapshailendra012@gmail.com', NULL, NULL, '325456', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-11 19:40:09', NULL, NULL),
(142, 'Jaya shrivastava', '9826178880', 'EWS-445 Kotra sultana bad Bhopal Madhya Pradesh', 'jhanki', 'a533e29949add9d1eeea9132ed46249d.jpg', 'jayashrivastava1981@gmail.com', NULL, 1, '303758', 'user', 1, '0ef0ea30915ef80d72539852428c0f39', '2021-09-11 19:40:21', NULL, NULL),
(143, 'Ramchandani ji', '9425079569', 'Royal Market', 'pandal', '3dfa6459fb2342c09b950ab41f668161.jpg', 'pratapshailendra012@gmail.com', NULL, 1, '654546', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-11 19:40:53', NULL, NULL),
(144, 'Rishav', '8962574597', 'Immami gate bhoapl', 'pandal', '346a17ce933e753dc3c2f3473551356f.jpg', 'rishav.sahu6559@gmail.com', NULL, NULL, '556540', 'user', 1, 'b6aee59036fae6ab7a03acdb3dcf9eb9', '2021-09-11 19:52:25', NULL, NULL),
(145, 'Shubham yadav', '8839199947', 'Peer gate bhopal', 'jhanki', 'aa34498ef70deb250de134ab4d959b28.jpg', 'shubhamyadav3141@gmail.com', NULL, 1, '854935', 'user', 1, '8fe6833df81e224e08ce9be4abfa89a0', '2021-09-11 20:01:00', NULL, NULL),
(146, 'Vivek Yadav', '7879809769', 'E-31', 'other', '03ae54c6c83fc821e297b7cea50b57f2.jpg', 'vyadavcs2015@gmail.com', NULL, 1, '219843', 'user', 1, 'bed128365216c019988915ed3add75fb', '2021-09-11 20:03:37', NULL, NULL),
(147, 'ANIKET KIRAR', '8770210511', 'H.No- 10 (F) Subhash colony Ashoka garden, Bhopal', 'other', '9714f6a4b3b35ba3ff2e538fc4fa0ce4.jpg', 'aniketkirar16@gmail.com', NULL, 1, '223132', 'user', 0, 'dd50923abcd26a5760e398b279508bf6', '2021-09-11 20:05:10', NULL, NULL),
(148, 'Vivek Yadav', '9098377614', 'E-31 Nehru Nagar', 'other', 'b0a016c6fea9ddea641974e78bc54cca.jpg', 'gamerworldvk@gmail.com', NULL, NULL, '304449', 'user', 1, '63ed83748460c0f2ce604e91d6ad97cf', '2021-09-11 20:09:39', NULL, NULL),
(149, 'Dr Sheetal Choudhari', '9827065462', 'D25 AMRA Estate Nayapura Kolar Road BHOPAL 462042 MP', 'other', '743cc17c1034e50e856ccd879c674e9f.jpg', 'drsheetaldc@rediffmail.com', NULL, 1, '294038', 'user', 1, '2beb1ad02ffe276d5f9e2e4314ff6389', '2021-09-11 20:59:21', NULL, NULL),
(150, 'Nohar Singh', '9754615567', 'E8/381 Ishwar Nagar Trilanga', 'jhanki', '45cde839bb35ab48b7b1b6f45aa4cd58.jpg', 'noharsingh065@gmail.com', NULL, 1, '494128', 'user', 1, 'f6db2d579bac861a804599eb91c62830', '2021-09-11 21:23:29', NULL, NULL),
(151, 'Sachin Sahu', '9424499701', 'A184 indra vihar colony airport road', 'other', 'cfe18cefeab05e59646f90e0f3eb3408.jpg', 'sahusachin1412@gmail.com', NULL, 1, '577506', 'user', 1, '5f93de03200f693d1549123a23dd3709', '2021-09-11 22:25:03', NULL, NULL),
(152, 'Aman Prajapati', '9826043709', 'LF 124 Kotra Sultanabad Bhopal', 'other', 'cc873f2021880f52f5cb314b58a654a8.jpg', 'amanprajapati93@gmail.com', NULL, 1, '722523', 'user', 1, '7392ea4ca76ad2fb4c9c3b6a5c6e31e3', '2021-09-11 22:53:41', NULL, NULL),
(153, 'Sarvagya Kaushik', '9424472330', 'E-7 ,RGPV Campus , Bhopal', 'other', 'ea261eab81160e66454c42a9ef54bc9a.jpg', 'sarvagyakaushik28@gmail.com', NULL, 1, '832516', 'user', 1, 'f6f1a400eb10a7c87ae88dcef09168f7', '2021-09-12 09:07:40', NULL, NULL),
(154, 'Devyani Kaushik', '8319192477', 'E-7 ,residential block ,RGPV Campus , Bhopal', 'other', 'e95dcb288184d50865e3e35b9676fe35.jpg', 'devyanikaushik20@gmail.com', NULL, 1, '796679', 'user', 1, '01bb14de1f21f2a08c492db9fbc65d52', '2021-09-12 09:13:52', NULL, NULL),
(155, 'Sandhydeep kashiv', '9977910081', 'L 288 sardaar vallabh bhai patel yojna...misrod faze 2', 'other', '6d7da9caae03df915e6456ad802be68c.jpg', 'kassandhy@gmail.com', NULL, NULL, '884343', 'user', 1, 'd8ec27451ec114634b829e96253c7728', '2021-09-12 12:20:13', NULL, NULL),
(156, 'Sandhydeep kashiv', '9977910081', 'L 288 sardaar vallabh bhai patel yojna...misrod faze 2', 'other', '1b7c4d971fae2530ebd789bccf4d0654.jpg', 'kassandhy@gmail.com', NULL, NULL, '475818', 'user', 1, 'd3016b0054ccfdd09b5ae0c514138b32', '2021-09-12 12:24:19', NULL, NULL),
(157, 'Sandhydeep kashiv', '9977910081', 'L 288 sardaar vallabh bhai patel yojna...misrod faze 2', 'other', '69495d0cd823849f1ddd22c2cd23d2f1.jpg', 'kassandhy@gmail.com', NULL, 1, '324717', 'user', 1, 'e74398f588838a34b824862c845cb0ee', '2021-09-12 12:40:21', NULL, NULL),
(158, 'Green City Society', '9826258125', 'Gulmohar, Ward No. 51, Bhopal', 'pandal', '4ff29eb803629035fc2d6e3e99321e34.jpg', 'greencitybpl@gmail.com', NULL, 1, '695629', 'user', 1, '94df98c5dc473e0ada19bb3b3f936911', '2021-09-12 12:45:53', NULL, NULL),
(160, 'Deepti Shukla', '7000180632', 'Katara Hills, Bhopal', 'other', 'b9d6c2c9772b12163472f1a18b0bbcf4.jpg', 'deepari2016@gmail.com', NULL, 1, '867808', 'user', 1, '58de87a0520945b91bd3e62b82c12d9c', '2021-09-12 13:57:27', NULL, NULL),
(161, 'Rashi Patel', '8871236731', '290 d sector Ayodhya nagar bhopal', 'other', '1294931ef19029fe643ff0955a351529.jpg', 'shivendra.patel7@gmail.com', NULL, 1, '315906', 'user', 1, '202cb962ac59075b964b07152d234b70', '2021-09-12 15:51:28', NULL, NULL),
(162, 'Chandra mohan gurjar', '9301104969', 'Samriddh Safayar Hinotiya Alam', 'other', '150d6327459f091634fd9fdb9c923531.jpg', 'siddhim1979@gmail.com', NULL, 1, '212253', 'user', 1, 'e807f1fcf82d132f9bb018ca6738a19f', '2021-09-12 16:27:02', NULL, NULL),
(163, 'Krishna Chourasia', '8085194172', 'H. No1400 krishna nagar coach factory road', 'other', '9ae4c28bc57dac4f5571411ba3845c20.jpg', 'Krishnachourasai21@gmail.com', NULL, 1, '449828', 'user', 1, '3d293d0fcbb073ad6fecaa925c6ba69c', '2021-09-12 18:17:39', NULL, NULL),
(164, 'Maneesh hazare', '9981597148', 'H. No. 115 neelkanth colony karond bhopal 462038 mp', 'other', '61a14218f81a2d0879be519f607a057f.jpg', 'rahup160195@gmail.com', NULL, 1, '609895', 'user', 1, 'e22bd2f43c8decb603adf9a60d7d0863', '2021-09-12 20:00:24', NULL, NULL),
(167, 'Bittu suryawanshi', '8602278860', '12 shree ram nagar indore', 'pandal', '88db072694b54dde9abbcc2fe6fcd40e.jpg', 'bittusuryawanshi26@gmail.com', NULL, 1, '331769', 'user', 1, 'ac36389e6525988c4ddb8bb3ef7c0a26', '2021-09-12 22:08:59', NULL, NULL),
(168, 'Anita sahu', '8602380492', 'Obaidullahganj', 'other', '6086bad89465a0231b6e185a2b1eb027.png', 'sahuanita212@gmail.com', NULL, 1, '565585', 'user', 1, '6627415e807ee33c7302917216e7da68', '2021-09-12 22:33:17', NULL, NULL),
(169, 'Anita sahu', '9713935634', 'Obaidullahganj', 'other', 'c4de663504f16c7c6096de20f987bdcd.jpg', 'sahuanita212@gmail.com', NULL, 1, '474471', 'user', 1, '1d7716c6cce2e3f456d3e74604f55da1', '2021-09-12 22:59:49', NULL, NULL),
(170, 'Shekhari Maheshwari', '9926900355', 'Gulmohar (Near Aura Mall) Shahpura', 'jhanki', '02baf2b67d609a7d9dadee0b5cae3c70.jpg', 'greencitybpl@gmail.com', NULL, 1, '113144', 'user', 1, '94df98c5dc473e0ada19bb3b3f936911', '2021-09-13 08:11:30', NULL, NULL),
(171, 'Tushar Srivastava', '8962255108', '301 Prince complex vijay nagar lalghati bhopal', 'other', '65637637f6c2806d593be30fd57ba35e.jpg', 'srivastava.t@gmail.com', NULL, 1, '204245', 'user', 1, 'd79dc0a75793adac7d664dfc4290a151', '2021-09-13 10:31:41', NULL, NULL),
(172, 'Prashant Shrivastava', '7566107007', 'T-3,Arihant Palace Old Ashoka Garden Bhopal', 'other', '9fb0f41362e63dd3803916f35b8ae3c2.png', 'shrivastava.prashant18@gmail.com', NULL, 1, '981349', 'user', 1, '80cbdd9fa707168a3eb1be8686e18ce5', '2021-09-13 11:34:33', NULL, NULL),
(173, 'Premlata Shrivastava', '9009622236', 'S1, Arihant Palace Old Ashoka Garden Bhopal', 'pandal', 'de2c98ed2b763bd006135f538349263d.jpeg', 'shrivastava.prashant18@gmail.com', NULL, 1, '859650', 'user', 1, '80cbdd9fa707168a3eb1be8686e18ce5', '2021-09-13 11:38:31', NULL, NULL),
(174, 'Gunjan Agrawal ', '7898669666', 'Shyamla hills bhopal ', 'other', '6dce1664b240177ffd6ac75f97ff0eac.jpeg', 'agrawalgunjan20@gmail.com', NULL, 1, '939562', 'user', 1, 'bd5da9287d37deca4260b10ea9bc5a27', '2021-09-13 12:09:41', NULL, NULL),
(175, 'Mahandra', '9826236516', 'Pacific Blue Society hoshangabad road Bhopal', 'other', '50810c6871b98032d68303f34a6979a9.jpg', 'mahendrachourey56@gmail.com', NULL, NULL, '880718', 'user', 1, '81dc9bdb52d04dc20036dbd8313ed055', '2021-09-13 12:53:53', NULL, NULL),
(176, 'Shelja savita', '8839286582', 'Vishwakrma nagar karond bhopal', 'other', 'd320116a38eb032cf5cbc4eef5c4530a.jpg', 'sheljasavita73@gmail.com', NULL, 1, '673527', 'user', 1, '25d55ad283aa400af464c76d713c07ad', '2021-09-13 14:57:54', NULL, NULL),
(177, 'Rani Thakur', '8830914736', 'Ayodhya Nagar phase 5', 'other', '320217fc4a631947c8d8ba3c215e7bd0.jpg', 'purviyabrijesh@gmail.com', NULL, 1, '508706', 'user', 1, '4d4e49163b8684e61bf34e17e22f09f1', '2021-09-13 17:23:47', NULL, NULL),
(178, 'sadhana Desai', '9425602475', '5/2 nNupurkunj E-3 Arera Colony, Bhopal', 'other', '94e1279901406a2541b4c2b6faf0ec8b.jpg', 'sadhana.apex@gmail.com', NULL, 1, '839030', 'user', 1, 'c0101aff4f4bb9014fc47235b5d51649', '2021-09-14 09:11:28', NULL, NULL),
(179, 'Sadhana Joshi', '8770875087', '146,Kalpana nagar ,Bhopal', 'other', '4988f414e25dd845a10b39009c7d8df7.jpg', 'sadhanajoshi131065@gmail.com', NULL, 1, '398076', 'user', 1, '3a5db0274d82427a8538e7deaaa208b1', '2021-09-14 10:31:11', NULL, NULL),
(180, 'Mangal Singh', '8435981483', 'Village Chitapura Teh. Itarsi Disst. Hoshangabad', 'other', 'a05cf8912390119cbeaeb9cd07d061d6.jpg', 'eavney123@gmail.com', NULL, 1, '540800', 'user', 1, 'ffac0ff0411376ee11a733407abcc12d', '2021-09-14 11:14:24', NULL, NULL),
(181, 'Dinesh Kumar Lodhi', '9604493614', 'Bhopal', 'other', '9339f6980c9b25e894814fe0fd4cfb8e.jpg', 'dinesh6325abc@gmail.com', NULL, 1, '239154', 'user', 1, 'ff27f56dfda9a3913a1bf6a6ac126c2a', '2021-09-14 11:34:06', NULL, NULL),
(182, 'Yatharth Ramoshi', '9617383976', '751,Durga nagar, Panchsherl nagar, Bhopal', 'other', 'b4ace75332b617e13fd51edc04a8cba7.jpg', 'pankajramoshi@gmail.com', NULL, 1, '476300', 'user', 1, '8bce529ba87abc7267e03ef24178bfd1', '2021-09-14 13:20:56', NULL, NULL),
(183, 'Akash Prajapati', '9575254440', 'Roshanpura Bus Stop', 'pandal', '9370e2db43b491529533b895f21d8587.png', 'ap750964@gmail.com', NULL, 1, '467611', 'user', 1, 'f1d7405cf06be812e5d2f9d5145a8dc7', '2021-09-14 18:05:09', NULL, NULL),
(184, 'Aditya Tiwari', '8839457488', '30,New friends society, chunnabhatti', 'other', '0bf561cdbcc863404dd2e3c0bd99afec.jpg', 'adi12342896@gmail.com', NULL, 1, '968025', 'user', 1, '2c57711e55a44189b6acde710f768f5d', '2021-09-14 21:52:18', NULL, NULL),
(185, 'rahul sharma', '9876543210', 'Bhopal', 'other', '5249af82cc0bc43444881dce0f172fa5.jpg', 'Sharm1980@gmail.com', NULL, NULL, '296294', 'user', 1, 'c568864335eb8173e85d8574ff09e0b1', '2021-09-14 22:44:55', NULL, NULL),
(186, 'Varun Thanwani', '7974436885', 'Lane 1, Risaldar Colony, Near Reliance Tower, Chhola Road', 'other', 'd5b3028aeee3ae9d3b012ee136e2141b.jpg', 'varunthanwani@gmail.com', NULL, 1, '596304', 'user', 1, 'f7d14c5e981c10e22485728559934ec1', '2021-09-15 00:39:14', NULL, NULL),
(187, 'Sunil Nema', '9425176189', 'BDA Colony Salaiya Misrod Bhopal', 'other', 'c5022ada912f6344d52c81c68c970b8f.jpg', 'sunil.nema7@gmail.com', NULL, 1, '266773', 'user', 1, '519957b5e0d5f0fc02315bb0c0e9ebce', '2021-09-15 08:49:32', NULL, NULL),
(188, ' Mahendra Kumar Choure', '9826236516', 'Pacific Blue Society, Hoshangabad Road, Bhopal', 'other', '734e1acceec394ac5ca5d960688f3931.jpg', 'mahendrachourey56@gmail.com', NULL, 1, '540733', 'user', 1, 'b8b05069c7365fe828b4de8eda9fd968', '2021-09-15 12:49:20', NULL, NULL),
(189, 'kamlesh maheshwari', '9320390340', 'B3/304, Pacific Blue Society, Hoshangabad Road', 'other', 'f86df4a0a34b9b27ed0a3d4f5da21503.jpg', 'maheshwari.kamlesh@gmail.com', NULL, 1, '561765', 'user', 1, '105f62ca0731777455686795eaf0b392', '2021-09-15 13:42:58', NULL, NULL),
(190, 'Ankit Mourya', '7389195475', 'mourya colony karond', 'pandal', 'e865652491660ae4e4737db01378cce0.jpg', 'ankitmourya6127@gmail.com', NULL, 1, '637276', 'user', 1, '770b0a4015ff5415b72393e0a2a1de85', '2021-09-15 18:48:56', NULL, NULL),
(191, 'Manish Khadagade', '9630368128', 'Ganpati homes Ayodhya nagar', 'other', '7e5f473ea1ccd2610b297b0b41515a47.jpg', 'khadagademk@gmail.com', NULL, 1, '180763', 'user', 1, '0b55258bedb2d2be76753198351e8903', '2021-09-17 20:01:57', NULL, NULL),
(192, 'Parv Soni', '7000843171', 'राजीव नगर बी सेक्टए अयोध्या बाईपास भोपाल', 'other', '0ca459c20cc1ac5ee334ec4216d36669.png', 'vijaywin.soni@gmail.com', NULL, 1, '989821', 'user', 0, '972bff7d624c161131fe7ca354c845a9', '2021-09-17 20:59:28', NULL, NULL),
(193, 'Yogendra Kumar Saxena', '9425677776', '105,DK Surbhi Appartment Gomti Colony Nehru Nagar Bhopal', 'other', '6321a2a821bd34c22b70f425c09695b4.jpg', 'dryksaxena5@yahoo.com', NULL, 1, '213496', 'user', 1, 'c33e2ac97b2d2847abbc10ae403fa406', '2021-09-19 19:14:33', NULL, NULL),
(194, 'nare', '9547800000', '4rggf', 'jhanki', 'f11382a9eeaf270c668d6d59f569a0c6.png', 'swadmin@gmail.com', NULL, NULL, '459820', 'user', NULL, '202cb962ac59075b964b07152d234b70', '2021-11-22 17:17:01', NULL, NULL),
(195, 'nare', '8818886801', 'dsdsdsd', 'jhanki', 'ef101a809f14c6a975e1c946e7262e2f.png', 'swadmin@gmail.com', NULL, 1, '960489', 'user', NULL, '202cb962ac59075b964b07152d234b70', '2021-11-22 17:17:47', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `email` text DEFAULT NULL,
  `pwd` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `pwd`) VALUES
(1, 'swadmin@gmail.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `old_data_2020`
--

CREATE TABLE `old_data_2020` (
  `id` int(10) NOT NULL,
  `name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `mobile` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `zone` int(10) DEFAULT NULL,
  `ward` int(10) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `profession` text DEFAULT NULL,
  `subject` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `image_type` text DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `participatename`
--

CREATE TABLE `participatename` (
  `id` int(10) NOT NULL,
  `participate_name` text DEFAULT NULL,
  `mobile_no` text DEFAULT NULL,
  `email_id` text DEFAULT NULL,
  `category` text DEFAULT NULL,
  `participate_address` text DEFAULT NULL,
  `date_time` datetime DEFAULT current_timestamp(),
  `image_pic` text DEFAULT NULL,
  `status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `participatename`
--

INSERT INTO `participatename` (`id`, `participate_name`, `mobile_no`, `email_id`, `category`, `participate_address`, `date_time`, `image_pic`, `status`) VALUES
(3, 'NEHA Ahirwar', '9111704292', 'nehaahirwar174@gmail.com', 'Street_Play', 'Choupda kala Vidisha road Bhopal m p', '2021-11-10 02:35:24', '3f5643af728ed3e6de367f95ff0ba064.jpg', '0'),
(4, 'ARJUN KALURAM AHIRWAR ', '8120650431', 'jiarjun326@gmail.com', 'Jingle_writing', 'DIG Bonglow Bhopal ', '2021-11-10 02:40:06', 'd9b5936851d17fce6a6f9b840847d0f0.jpg', '0'),
(6, 'à¤®à¤¾à¤¨à¤¸à¥€ à¤šà¥Œà¤¹à¤¾à¤¨', '9399685751', 'mansichouhan2020@gmail.com', 'Poster_Design', 'Near ghorakhnath mandir Shiv nager Vidisha road Bhopal', '2021-11-10 06:55:21', 'f8166f9c792b8c5aa97f6b68340385e0.jpg', '0'),
(9, 'Vivek bamhan', '8517855136', 'vivekbamhan123@gmail.com', 'Poster_Design', 'Zone 05 Health department kamla park bhopal', '2021-11-10 10:06:40', 'bc4fcf528bd4dfe7fc822cc1b137c0b3.jpg', '0'),
(11, 'Vinod Nagar ', '7470984019', 'vinodnagar7470984019@gmail.com', 'Jingle_writing', 'Hinoti sadak ', '2021-11-10 20:44:00', 'bacddb586d7a4e32626bf4a25337ca62.jpg', '0'),
(12, 'Preeti ahirwar', '9109069852', 'Preeti ahirwar', 'Short_Movie', '10katara', '2021-11-10 23:02:20', 'ceae58dae1a155ad71a09dafd2e62cc6.jpg', '0'),
(18, 'Neelu Ahirwar', '6260439758', 'neeluneeluahirwar@gmail.com', 'Jingle_writing', 'Samrdha bhopal', '2021-11-11 00:03:22', 'c8fa36b5fd2ec63d373ed0218c13f004.jpg', '0'),
(22, 'Anam khan ', '6260618918', 'sk5456337@gmail.com ', 'Poster_Design', 'Home number 348 nariyal kheda nagar nigam colony bhopal ', '2021-11-11 05:41:20', '04f851382a783669673aab00229564a3.jpg', '0'),
(23, 'Anjali sonkar', '9617251959', 'dilipksonkar@gmail.com', 'Poster_Design', 'N2 D sector', '2021-11-11 07:30:32', 'af4bf776d809899e0fff267322694e0f.mnn', '0'),
(24, 'Pinky paraste', '7240921205', 'Ganesh parasteganesh806@gmail.com', 'Short_Movie', 'Excel state', '2021-11-11 09:00:25', '439fa6c04dd8abae69942e74f835babc.jpg', '0'),
(25, 'Sapna perwal', '9301139761', 'rajeshraj7222959@gmail.com', 'Street_Play', 'rajeshraj7222959@gmail.com', '2021-11-11 17:59:58', '35e22ec2bd53e0cca0b90c1f0f6aeaf0.jpg', '0'),
(27, 'Sandhya Mankar', '8109989847', 'sm1703937@gmail.com', 'Poster_Design', 'Bhopal', '2021-11-12 07:30:45', 'c704f5afe7f20bfd86f8fae085fd947e.jpg', '0'),
(28, 'Kiran jaiswal ', '8959145917', 'pankajjaiswal3464@gmail.com', 'Poster_Design', 'Leabar colony indrapuri bhopal M.P ', '2021-11-12 08:31:54', 'de2f1a8cc869153072c507ff21fa9c46.jpg', '0'),
(29, 'Aman Parashar ', '8982712110', 'amanparashar072@gmail.com', 'Jingle_writing', 'Ahinsa Dwar, Biaora, District Rajgarh, Madhya Pradesh ', '2021-11-12 13:04:13', '33658c87381779167f7e648e5bd34369.jpg', '0'),
(30, 'Mahesh kulshreshtha', '7692038650', 'www.mharomalwo064@gmai.com', 'Street_Play', 'Near,Thana ground pratappura nalkheda tah.nalkheda dis. Agar malwa mp.', '2021-11-12 23:20:54', 'f2e2f76fd1021e484a6f697563af2be8.jpg', '0'),
(31, 'Manoj', '8349380244', 'Principalman07@gmail.com', 'Jingle_writing', 'Alirajpur', '2021-11-13 00:22:13', 'b05faf59149bbc9c1421dfff6caffc3a.jpg', '0'),
(32, 'Pankaj Kumar Tiwari', '7509299072', 'pankaj.apn92@gmail.com', 'Jingle_writing', 'Ghuisa amarpatan satna', '2021-11-13 07:59:40', '82c9c698b7f539c5baf20ffda49b48c9.jpg', '0'),
(33, 'Poonam Shastri', '8839640472', 'poonamshastri1971@gmail.com', 'Wall_Piant_Mural', 'Regal paradise -1, awadhpuri BHEL Bhopal MP', '2021-11-13 09:25:32', '4be1a3907eb85a3fac9b563396d0e29d.jpg', '0'),
(34, 'Ravi', '8435106691', 'ravirathore6691@gmail.com', 'Short_Movie', 'House 12 suraj nagar', '2021-11-13 09:37:41', 'f6a6ff3fd82fa761ccabeeca23c4cbde.jpg', '0'),
(35, 'Santanu Datta', '9474543181', 'santanudatta874@gmail.com', 'Poster_Design', 'Bazar Road. Ward no 4; P.O Mathabhanga.', '2021-11-13 10:02:03', '24a9b2998675ef541bcf4f55417236cd.jpg', '0'),
(36, 'Shivangi Bajpai', '8319727307', 'nbajpai344@gmail.com', 'Short_Movie', '2/44 B.D.A colony amrawat khurd Bhopal', '2021-11-13 20:41:43', 'cd4ad144c6836f6c871b8c14b628c07f.pdf', '0'),
(37, 'Dr Sushma Jadon', '9425358667', 'Sushmajadon.dr@gmail.com', 'Jingle_writing', '103, Amarnath Colony Kolar Road Bhopal', '2021-11-14 04:14:09', '1cd5e9e5b883dced89c1ce7e6d45b9af.jpg', '0'),
(38, 'Samiya Mansuri', '8770610761', 'mansurireshma@gmail.com', 'Poster_Design', '282 N/1,A sector Govindpura Bhopal', '2021-11-14 05:56:11', 'b31b6c2d71666879d5dabc8827f43367.jpg', '0'),
(39, 'Devendra Kumar sahu', '9179693627', 'dks917969@gmail.com', 'Wall_Piant_Mural', 'Badamalehra dist chhatarpur', '2021-11-14 08:44:29', 'c4b5e1931e6cf0f62b2847ce9d2f005f.jpeg', '0'),
(40, 'arti meena', '8085542771', 'artimeena9516@gmail.com', 'Short_Movie', 'house no. 1 ,anand kunj, kurawar ,dist. rajgharh ,m.p.', '2021-11-14 18:31:36', '1b61ca79860316b37c09a7b5ac01a7eb.jpg', '0'),
(41, 'Gauranga Chandra Behera', '9830147888', 'gcb4000@gmail.com', 'Jingle_writing', 'Plot No - 80,   Lane - 9,  Soubhagya Nagar,  Bhubaneswar,  Odisha   PIN - 751003', '2021-11-15 23:13:48', '883291b744f0364af31de49ab7dbc671.docx', '0'),
(42, 'Subhankar Priyadarshi', '7538030160', 'pintu4000@gmail.com', 'Jingle_writing', 'C/O-Nityananda Behera,  SBI CSP, Station Bazar, Rupsa,  PO-Rupsa, Dist-Balasore   Odisha   756028', '2021-11-16 00:05:20', 'baf2be952cefd72646e8b8ab7581d9b7.jfif', '0'),
(43, 'PRATIVA BEHERA', '9439916826', 'prativa4000@gmail.com', 'Jingle_writing', 'C/O - Kumar Beda Gourab, Tanishq showroom, Near Chidia Pola, Balasore   Odisha    PIN - 756001', '2021-11-16 00:24:39', '8fb4b92a2044bd78afe5aef792072e2f.pdf', '0'),
(44, 'Aarti Mastakar ', '7980177016', 'vkmast8@gmail.com', 'Jingle_writing', 'Fl. 307, Amrit Dhaam Apartment, Nitya Nand Nagar, Near Bakultala Check Post, Andul Road', '2021-11-16 00:48:44', '3d5203115a09ea49c50e4c8a4868c3c3.jpg', '0'),
(45, 'Ipsita Priyadarsini', '7978066212', 'rinki4000@gmail.com', 'Jingle_writing', 'C/O-Sumanta Ku Behera, Dasarathapur Block Office, Jhumpuri Bazar, Dist - Jajpur, Odisha  PIN-755006', '2021-11-16 00:51:36', '499b2f640cff96bce91b1ef5bf662aef.pdf', '0'),
(46, 'Rahul Thakral', '8875294743', 'rahulthakral4743@gmail.com', 'Jingle_writing', 'House number 72 sector A rajharsh colony lalitanagar kolar road Bhopal 462042', '2021-11-16 06:05:05', '58d2f0d926a6c2a5e486c8f8e03bf193.jpg', '0'),
(47, 'Ashwini sahu', '8889950453', 'ashwinisahu59@gmail.com', 'Poster_Design', '51ashok nagar', '2021-11-16 07:40:06', 'bdbb098ebde22191707512ebcd6b2e6e.jpg', '0'),
(48, 'Vikash Pandey', '9770614938', 'vikashpan2233@gmail.con', 'Jingle_writing', 'Rewa', '2021-11-16 09:02:21', 'd7e258cfb3e839c348633d12f0fe4a84.jpeg', '0'),
(49, 'Kunal singh jat', '9691396979', 'jatkunal671@gmail.com', 'Short_Movie', 'Shivani homes colony Bhopal Madhya Pradesh', '2021-11-16 10:51:36', '5a8d0f4ddc78d1be5f4d6d2c05f623ba.jpg', '0'),
(50, 'à¤…à¤¸à¥€à¤® à¤•à¥à¤®à¤¾à¤° à¤¦à¥à¤¬à¥‡', '9425602316', 'aseem.dubey1@gmail.com', 'Jingle_writing', '127-à¤¬à¥€, à¤¡à¥€à¤•à¥‡-5, à¤¦à¤¾à¤¨à¤¿à¤¶ à¤•à¥à¤à¤œ, à¤•à¥‹à¤²à¤¾à¤° à¤°à¥‹à¤¡, à¤­à¥‹à¤ªà¤¾à¤²-462042', '2021-11-16 23:01:44', '98cf16f736d2614832c9d80f09d451ce.docx', '0'),
(51, 'Santosh kol', '6260586474', 'santoshkol34697@gmail.com', 'Poster_Design', 'Anuppur mp', '2021-11-18 09:24:09', 'fb02f8482cd9fb65f214129ccef05383.jpg', '0'),
(52, 'Akhilesh kumar Verma', '9171016069', 'Verma18akhilesh@gmail.com', 'Poster_Design', 'A / 70 Shastri Nagar bhad bhada Road Bhopal, A/70 Shastri Nagar Bhad bhada Road Bhopal', '2021-11-18 20:46:53', '5296422ae8e5fb752bd346c722500223.png', '0'),
(53, 'Dr DINESH CHOUDHARI', '9827065462', 'drdinessh007@gmail.com', 'Wall_Piant_Mural', 'D-25 Amra State Nayapura kolar Road BHOPAL MP 462042', '2021-11-18 22:19:58', '66f2871fa2ee675c061b8c4f50f36a70.jpg', '0'),
(54, 'Dr Sheetal Choudhari', '9407486808', 'drsheetaldc@rediffmail.com', 'Wall_Piant_Mural', 'D-25 Amra State Nayapura kolar Road BHOPAL', '2021-11-18 22:23:05', '1f4abc3fbc2980948e4285e56f30bc17.jpg', '0'),
(55, 'Damimi lodhi', '7879502995', 'pratikshalodhi7@gmail.com', 'Poster_Design', 'Naveebhag berasia road Karond Bhopal', '2021-11-18 23:07:34', '855171449f871d6f093d36e101b38676.jpg', '0'),
(56, 'AJAY SISODIYA', '8305025035', 'ajaysisodiya1852@gmail.com', 'Jingle_writing', 'Ward no 15 Satlapur Mandideep ', '2021-11-19 00:31:15', 'ac578a4c8447e010b438120f0ca3043c.png', '0'),
(57, 'RAVI SISODIYA', '9285425000', 'vikashsisodiya860@gmail.com', 'Jingle_writing', 'Ward no 15  Mandideep bhopal', '2021-11-19 00:41:43', '050d589f3d73a4e1647a8867f5f8f352.png', '0'),
(59, 'ramkrishan Patel', '6268704066', 'ramkrishankurmi27@gmail.com', 'Wall_Piant_Mural', 'à¤—à¥à¤°à¤¾à¤® à¤¸à¤²à¥ˆà¤¯à¤¾ à¤ªà¥‹à¤¸à¥à¤Ÿ à¤¬à¤²à¥‡à¤¹ à¤¤à¤¹à¤¸à¥€à¤² à¤°à¤¹à¤²à¥€ à¤œà¤¿à¤²à¤¾ à¤¸à¤¾à¤—à¤°', '2021-11-19 05:04:22', '1271e06c01440355dc9cf1d253d4b017.jpg', '0'),
(60, 'Hareesh kumar', '9644222588', '181hareesh@gmail.com', 'Poster_Design', 'Village khamkhareli Post bandol district seoni Madhya Pradeshr', '2021-11-21 04:48:52', 'a418c8b52aee9b60b16e9fe26856ea1f.jpg', '0'),
(61, 'Alpana Jha', '9425012114', 'alpnajha17@gmail.com', 'Short_Movie', 'House no 4 Bharat Nagar JK road BHEL Bhopal', '2021-11-21 07:38:03', '93bf0e36ad267957c8a48ad7213672b8.mp4', '0'),
(62, 'Vijay kumar', '7268982853', 'vkmauryaadmaurya@gmail.com', 'Poster_Design', 'Karkoli, karma, ghorawal, sonbhadra, Uttar Pradesh', '2021-11-22 04:42:11', 'bde2e0bfd578cf11b287a22d84c02bec.jpg', '0'),
(63, 'Ashish Shrivastava', '8871584907', 'ashish35.srivastava@yahoo.in', 'Jingle_writing', '204, Kotra near vivekanand park, Bhopal Madhya Pradesh 462003', '2021-11-23 01:31:53', '447603f86a4ea55436222d8ceb349bf2.docx', '0'),
(64, 'Vijay kumar', '9198306465', 'mauryaudham@gmail.com', 'Poster_Design', 'Karkoli, karma, ghorawal, Sonbhadra', '2021-11-24 06:31:11', 'eca4c6197c9b2280131b3ece8f3cc878.pdf', '0'),
(65, 'Natrajan Performing Arts', '7389180780', 'natrajanwelfaresociety@gmail.com', 'Street_Play', 'B-196, Green Park Colony, Near Mary Doll School, DIG Bunglow, Berasia Road Bhopal 462001', '2021-11-27 08:43:24', 'f71bac9dac988521436ed6b9c2159b16.jpg', '0'),
(66, 'Aashi patidar', '7999248536', 'aashipatidar11@gmail.com', 'Poster_Design', 'House no.11 village deepdi ,near bangrasiya road  bhopal.', '2021-11-27 23:41:13', '528a5c35bdd85600c29053d6e51cb3e7.jpg', '0'),
(67, 'SIDDHARTH PAUL', '7880289765', 'siddharthpaul80@gmail.com', 'Poster_Design', '105, Avinash Nagar, Berkhera Pathani, Bhopal, M. P. -462022', '2021-11-28 05:43:18', '44e1e8e5e66ed46d2e2d719147cf7cf3.jpg', '0'),
(68, 'Muskan chouhan', '9893732539', 'muskanchouhan97@gmail.com', 'Jingle_writing', '15, DEEP MOHINI VICTRY PARK RATANPUR SADAK', '2021-11-28 06:25:17', 'e7fb76ca32efd0bdb334a215b0aa32b4.jpg', '0'),
(69, 'Divyansh chouhan', '8989967933', 'divyanshchouhan121@gmail.com', 'Jingle_writing', 'Hno 15 deep mohini 11 mile', '2021-11-28 08:27:34', 'b57ac2241e51bbe3be0fefdf79d71494.jpg', '0'),
(70, 'Rashi patidar', '9399533486', 'rashipatidar317@gmail.com', 'Jingle_writing', 'House no.11 village deepdi  bhopal near bangrasiya road.', '2021-11-28 18:33:24', '5e50c2c6745fb04bcb2ac9e9cbb11365.jpg', '0'),
(71, 'Shyam vishwakarma', '9165656862', 'bbkhs1007@gmail.com', 'Poster_Design', 'Govt.HSS Bawadiya kalan Bhopal', '2021-11-28 23:17:22', 'b93e98fa0488bc9e194a87cd84428d8e.jpg', '0'),
(72, 'Kartik Sharma', '6261619840', 'kartiksharma08658@gmail.com', 'Poster_Design', 'H no- 359 Vallabh Nagar Bhopal', '2021-11-29 07:13:19', 'f1081a1a1f033455a53804e9e6d6aa65.jpg', '0'),
(73, 'Dr Sushma Jadon', '9425372706', 'vpsjdon@gmail.com', 'Jingle_writing', '103, Amarnath Colony, Kolar Road Bhopal - 462042', '2021-11-29 08:45:56', '7d2b170a1845feed726318487cc4691f.pdf', '0'),
(74, 'Riya Rahangdale ', '7999426292', 'Shikharahangdale2000@gmail.com', 'Poster_Design', 'F-1 block 17 indira nagar phase 2 jathkhedi ', '2021-11-29 22:16:26', '81ee9610ea32e45540ffb15736646b37.pdf', '0'),
(75, 'Raksha Jatav', '8109960591', 'pathakanil268@gmail.com', 'Poster_Design', 'Govt.HSS Bawadiya kalan Bhopal', '2021-11-29 23:13:47', '1f08fe1e8c57b97c77846f3a394c2cda.jpg', '0'),
(76, 'Anjali Jatav', '7898735998', 'kaptansinghchauhan.2014@gmail.com', 'Poster_Design', 'Govt.HSS Bawadiya kalan Bhopal', '2021-11-29 23:28:42', '199ac0374bdafb0ef4db457d41b9a0a4.jpg', '0'),
(77, 'Riya Rahangdale ', '9111843574', 'riyarahangdale661@gmail.com', 'Poster_Design', 'F-1 block 17 indira nagar phase 2 jathkhedi ', '2021-11-29 23:29:36', '80c9299d43e494372b2041dfd5806dfe.jpg', '0'),
(78, 'Abhishek Patel', '9770831347', 'sheebakhan02021989@gmail.com', 'Poster_Design', 'Govt.HSS Bawadiya kalan Bhopal', '2021-11-29 23:31:46', '69343b49ecb57b9d89d1acc55f8608d6.jpg', '0'),
(79, 'Sharda Patel', '9575584897', 'arvindshrivastava47@gmail.com', 'Poster_Design', 'Govt.HSS Bawadiya kalan Bhopal', '2021-11-29 23:39:13', '0b0e08a4c0764bb4c7b36b5a5a253482.jpg', '0'),
(80, 'Babli Kushwaha', '8435686537', 'rajendraprasadpatel1306@gmail.com', 'Poster_Design', 'Govt.HSS Bawadiya kalan Bhopal', '2021-11-29 23:43:12', 'cdc12d598a047281144e0d42fd3718f5.jpg', '0'),
(81, 'Shubham Pandey', '8349000159', 'er.shubh2323@gmail.com', 'Short_Movie', 'C-44 Samrat Colony Ashoka Garden Bhopal (462023)', '2021-11-30 00:34:23', '1e0e6c165e49db72140b862542a5e655.mp4', '0'),
(82, 'Shraddha Rathore', '6267169083', 'shraddharathore554@gmail.com', 'Poster_Design', 'Mig 04 Patel Nagar Mandideep Bhopal', '2021-11-30 01:54:37', 'c75b6d1e610186cde54f554954d2d911.jpg', '0'),
(83, 'Khushi Rathore', '8319686285', 'tarathore00@gmail.com', 'Poster_Design', 'LIG 06 Patel Nagar Mandideep Bhopal', '2021-11-30 01:57:16', '9ebf561d5a988e01dc8e4d011887aba4.jpg', '0'),
(84, 'Shobha Raghuwanshi ', '6260591651', 'shobharaghuwanshi276@gmail.com', 'Poster_Design', 'Mahaveer colony Bareli road near gyandeep school Silwani,Distt(Raisen)', '2021-11-30 04:50:49', '07005be02074c207754625614a8009e5.jpeg', '0'),
(85, 'Sarthak Jain', '7869208623', 'ssarthakjain@outlook.com', 'Short_Movie', '1/179 BDA COLONY, AMARWAD KHURD, AWADHPURI, BHOPAL, 462022', '2021-11-30 06:52:46', '695e4093b8e45b1307d0359f030b1eed.jpg', '0'),
(86, 'Monika Gandharva', '6265041291', 'monikagandharva123@gmail.com', 'Short_Movie', 'Dushehra Maidan Chhola, Bhopal', '2021-11-30 08:08:11', 'e5fb8b88d86f042f45d88cb7a0a34891.jpg', '0'),
(87, 'Kavish nukkad natak and (Devashish)', '7240868856', 'kavishnukkadnatak@gmail.com', 'Street_Play', '319 Vikas nagar govindpura bhopal', '2021-11-30 19:55:07', '9bdba09483117cd1f6be39649c839027.mp4', '0'),
(88, 'Kavish Nukkad Natak Group (Rahul Dhurve)', '7974935066', 'tenarasudevashish255@gmail.com', 'Street_Play', '319 Vikas nagar govindpura bhopal', '2021-12-01 00:25:51', 'ad8cf2412e81b3e44c2bb9f607ff8dea.jpg', '0'),
(89, 'Punita Malviya ', '9691322550', 'punita2700@yahoo.com', 'Poster_Design', 'Rohit Nagar, Salaiya, Bhopal ', '2021-12-01 03:07:31', 'b65f461d96cc5d368eae599b6cedba8e.jpg', '0'),
(90, 'RAMPHAL SOLANKI', '9993793553', 'ramphalsolanki@gmail.com', 'Jingle_writing', '209 B VAISHNAV BUILDING, SURENDRA PALACE HOSHANGABAD ROAD BHOPAL', '2021-12-01 04:57:41', 'afa716a3d5cd0a3452002a14401332c9.pdf', '0'),
(91, 'Arpita Dongre ', '7224874559', 'arpitadongre08@gmail.com', 'Poster_Design', 'A-2/T-2', '2021-12-01 11:26:17', '6dd1fe662ef6fae37215479a4093c530.jpg', '0'),
(92, 'Kalpana C Kekre', '8109145611', 'kalpana.kekre@gmail.com', 'Short_Movie', 'A-150 Shahpura A sector', '2021-12-01 12:20:52', 'b900dab5d3854e0a4231571a1dd07ce7.mp4', '0'),
(93, 'Siddhi Mishra ', '9977004422', 'riddhisiddhi1529@gmail.com', 'Jingle_writing', 'D-404, Fortune Signature, Opposite Pushpanjali Hospital, Near Shahpura Thana, Bawadiya Kalan, Bhopal', '2021-12-01 23:40:49', '486f541736bbc1d857815ec35f774716.pdf', '0'),
(94, 'Anshul Singh Thakur', '7697108610', 'anshulthakur26@gmail.com', 'Street_Play', 'J-15 Gokuldham Colony Opp. New jail road, Bhopal', '2021-12-02 09:41:50', '9d0d1cfa0d2b68ef0d199f4124b8ff76.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `participatetechname`
--

CREATE TABLE `participatetechname` (
  `id` int(11) NOT NULL,
  `participate_name` text DEFAULT NULL,
  `mobile_no` text DEFAULT NULL,
  `email_id` text DEFAULT NULL,
  `participate_address` text DEFAULT NULL,
  `image_pic` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `participatetechname`
--

INSERT INTO `participatetechname` (`id`, `participate_name`, `mobile_no`, `email_id`, `participate_address`, `image_pic`) VALUES
(1, 'Anupama kaithvas', '9177518980', 'anupama.kaithvas@yahoo.com', '', 'Kolar'),
(3, 'Dinesh kumar sharma', '9300382381', 'honey2014.ds54@gmail.com', '', 'Bhagwati  Vila bagicha no 10,city road,neemuch'),
(4, 'Dinesh kumar sharma', '9300382381', 'honey2014.ds54@gmail.com', '', 'Bhagwati  Vila bagicha no 10,city road,neemuch'),
(5, 'Saanvi Karambelkar', '9826050109', 'swapnil.tps@gmail.com', '', '316/9A Saket Nagar Bhopal'),
(6, 'Saanvi Karambelkar', '9826050109', 'swapnil.tps@gmail.com', '', '316/9A Saket Nagar Bhopal'),
(7, 'Mayank raghuwanshi', '9589291392', 'mayankraghu1@gmail.com', '', 'Ward.15 Silwani'),
(8, 'Vikram kurmi ', '7441184468', 'vikramkurmidmo@gmail.com', '', 'Gram semra bujurg post jortala kalan tahseel pathriya dist.damoh'),
(9, 'Vikram kurmi ', '7441184468', 'vikramkurmidmo@gmail.com', '', 'Gram semra bujurg post jortala kalan tahseel pathriya dist.damoh'),
(10, 'SACHIN AHIRWAR ', '6266045720', 'sachinahirwar9926@gmail.com', '', 'Khairana Rehli Sagar 470227'),
(11, 'SANGEET SAHARE', '9425665012', 'sangeetsahare@gmail.com', '', '220 Rohit nagar phase-2 bhopal'),
(12, 'Geeta rajput', '8827283521', 'jya@gmail.com', '', 'à¤¨à¤¾à¤—à¤¾à¤°à¥à¤œà¥à¤¨'),
(13, 'Jay', '8878375721', 'geetajay@gmail.com', '', 'Goplnagr'),
(14, 'Firoz Ahmad khan', '8962128407', 'fka0548@gmail.com', '', 'A 378 H B Colony'),
(15, 'Dinesh kumar sharma', '9300382381', 'honey2014.ds54@gmail.com', '', 'Bhagwati  Vila bagicha no 10,city road,neemuch');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `files_uploaded`
--
ALTER TABLE `files_uploaded`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `old_data_2020`
--
ALTER TABLE `old_data_2020`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `participatename`
--
ALTER TABLE `participatename`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `participatetechname`
--
ALTER TABLE `participatetechname`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files_uploaded`
--
ALTER TABLE `files_uploaded`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `old_data_2020`
--
ALTER TABLE `old_data_2020`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `participatename`
--
ALTER TABLE `participatename`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `participatetechname`
--
ALTER TABLE `participatetechname`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
