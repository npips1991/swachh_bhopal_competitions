<?php 
include('../include/config.php');

$obj = new db_class();

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo TITLE;?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,500,600,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/bootstrap.min.css?v=<?php echo rand(1000,10000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/all.min.css?v=<?php echo rand(100,1000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/owl.carousel.min.css?v=<?php echo rand(100000,1000000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/tp-animation.css?v=<?php echo rand(10,100); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/style.css?v=<?php echo rand(100000,1000000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/responsive.css?v=<?php echo rand(1000,10000); ?>" media="all">    
</head>
<style>
    body  {
        background-image: url("http://localhost/narendra/Swachh_Bhopal_Competitions/images/background.png");
        background-repeat: no-repeat;
        }
   .aa{
        background-image: url("images/3.png");
        background-repeat: no-repeat;
        height: 52em;
    }
</style>
<body>
    <!-- perload section -->
    <div id="preloader">
        <div id="preloader-inner"></div>
    </div>
    <!-- header section -->
    <header class="tp-main-menu header-menu-1 sticky-header">
        <!-- top logo/contac inf -->
        <div class="container">
            <div class="row row_menu_1">
                <div class="col-lg-6 col-md-6 col-12 col-logo-3">
                  
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <nav class="tp-menu tagpoint-menu-2">
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- breadcurmbs -->
    <img src="<?php echo BASE_URL; ?>/images/1.png">
    <section class="dropex-section faq-section">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-md-12">
                <div class="section-head" style="text-align: center;">
                    <img src="<?php echo BASE_URL ?>images/Swachh_Pratispardha_full.png" class="img-responsive" style="width: 45em;padding-bottom: 2em;">
                    <a href="registration.php">
                            <button type="button" class="btn btn-default animate-scale-btn" style="background: #e31e24;color: #fff;font-weight: 900;border-radius: 3em;">PARTICPATE NOW</button>
                        </a></span>
                </div> 
            </div>
        </div>		
    </section> 
    <script src="<?php echo BASE_URL ?>js/jquery.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/owl.carousel.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/odometer.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/progressbar.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/masonary.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/multipleFilterMasonry.js"></script>
    <script src="<?php echo BASE_URL ?>js/light-box.js"></script>
    <script src="<?php echo BASE_URL ?>js/noframework.waypoints.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/index.js"></script>
</div>
</body>
</html>