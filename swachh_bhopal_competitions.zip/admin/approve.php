<?php
	include('include/config.php');
	if(isset($_GET['id'])){
        $id=$_GET['id'];
        $obj = new db_class();
        $msg = $obj->approve($id);
        if($msg){
			$msg ='<div class="alert alert-success alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<h4><i class="icon fa fa-check"></i> Alert!</h4>
				Successful update.
			  </div>';
			}else{
				$msg ='<div class="alert alert-success alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<h4><i class="icon fa fa-check"></i> Alert!</h4>
				Error
			  </div>';			
			}    
        }
	header('location: adminview.php');
?>