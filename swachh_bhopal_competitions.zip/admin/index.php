<?php 
    session_start(); 
    include('../include/config.php');

    $obj = new db_class();
	
	if(isset($_POST['submit'])){
		$obj = new db_class();
		$email = $_POST['email'];
		$pwd = $_POST['pwd'];
		
		$error = false;
		$email_error = $password_error =  '';
		if(empty($email)){
			$error = true;
			$email_error = 'Email is required';
		}
		if(empty($pwd)){
			$error = true;
			$password_error = 'Password Is required';
		}
		if(!$error){
		$result = $obj->login($email, $pwd);
		if( $result->num_rows > 0 ){
				while($row = $result->fetch_assoc()){
					session_start();
					$_SESSION['id'] = $row['id'];
					header('location:adminview.php');
				}
			}else{
				$error_msg = '<div class="alert alert-danger alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<h4><i class="icon fa fa-check"></i> Alert!</h4>
					invalid Credentials
				  </div>';
			}
		}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo TITLE;?></title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="index2.html"><b><?php echo TITLE;?></a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <form method="post">
        <div class="input-group mb-3">
        <input class="form-control" type="text" placeholder="Email" name="email" autofocus>
			
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
          
        </div>
        <span style="color:red;"><?php if(isset($email_error)){ echo $email_error;} ?></span>
        <div class="input-group mb-3">
        <input class="form-control" type="password" placeholder="Password" name="pwd">
			
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
          
        </div>
        <span style="color:red;"><?php if(isset($password_error)){ echo $password_error;} ?></span>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">
                Remember Me
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
          <input type="submit" class="btn btn-primary btn-block" name="submit" value="Submit"/>
          </div>
          <!-- /.col -->
        </div>
      </form>
  </div>
</div>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
