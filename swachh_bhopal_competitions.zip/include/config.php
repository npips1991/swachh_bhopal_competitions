<?php 
define('BASE_URL', 'http://localhost/swachh_bhopal_competitions/');

define('TITLE', 'Swachh Bhopal Competition');

    define('db_host', 'localhost');
	define('db_user', 'root');
	define('db_pass', '');
	define('db_name', 'swachh_bhopal_competition');

    class db_connect{	
		public $host = db_host;
		public $user = db_user;
		public $pass = db_pass;
		public $dbname = db_name;
		public $conn;
		public $error;
		
		
		public function connect(){
			$this->conn = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
			if(!$this->conn){
				$this->error = "Fatal Error: Can't connect to database" . $this->connect->connect_error();
				return false;
			}
		}
	}

    class db_class extends db_connect{ 

        public function __construct(){
			$this->connect();
		}
		
		public function __destruct(){
			
		}

        public function ParticipateName($participate_name,$mobile_no,$email_id,$category,$participate_address,$image){
            $status= $this->conn->query("INSERT INTO participatename(participate_name,mobile_no,email_id,category,participate_address,image_pic,status)VALUES('$participate_name','$mobile_no','$email_id','$category','$participate_address','$image','0')");            
            if(!$status){
                $msg='<div class="row"><div class="col-md-6"><div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                    Error
                  </div></div></div>';
            }else{
                $msg ='<div class="alert alert-success">
                you have successfully submitted your entry!
              </div>';
            }
            return $msg;
        } 

		public function login($email, $pwd){
			$a = md5($pwd);
			$query = "SELECT * FROM login WHERE email = '$email' AND pwd = '$a'";
			$result = $this->conn->query("SELECT * FROM login WHERE email = '$email' AND pwd = '$a'");
			return $result;
		}

		public function getCategoryName(){
			$query = "SELECT * FROM participatename ORDER BY date_time DESC";
			$result = $this->conn->query($query);	
			return $result;
		}

		public function gettecCategoryName(){
			$query = "SELECT * FROM participatetechname";
			$result = $this->conn->query($query);	
			return $result;
		}

		public function approve($id){			
			$query = "UPDATE participatename SET status='1' WHERE id= '$id'";
			$result = $this->conn->query($query);
		}

		public function check_email_exist($email_id){
			try{
				$query = "SELECT Id FROM participatename WHERE email_id='$email_id'";
				$check = $this->conn->query($query);
				return $check->num_rows;
			}catch (Exception $e) {
				return $e->getMessage();
			}    	
		}

		public function check_mobile_exist($mobile_no){
			try{
				$query = "SELECT id FROM  participatename WHERE mobile_no='$mobile_no'";
				$check = $this->conn->query($query);
				return $check->num_rows;
			}catch (Exception $e) {
				return $e->getMessage();
			}    	
		}

		public function ParticipateTechName($participate_name,$mobile_no,$email_id,$participate_address,$image){
            $status= $this->conn->query("INSERT INTO participatetechname(participate_name,mobile_no,email_id,participate_address,image_pic)VALUES('$participate_name','$mobile_no','$email_id','$participate_address','$image')");            
            if(!$status){
                $msg='<div class="row"><div class="col-md-6"><div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                    Error
                  </div></div></div>';
            }else{
                $msg ='<div class="alert alert-success">
                <strong>Success!</strong> registration.
              </div>';
            }
            return $msg;
        }

    }

?>