<?php 
include('include/config.php');

$obj = new db_class();

	if(isset($_POST['submit'])){
        $participate_name = (isset($_POST['participate_name'])) ? $_POST['participate_name']:"";
        $mobile_no = (isset($_POST['mobile_no'])) ? $_POST['mobile_no']:"";
        $email_id = (isset($_POST['email_id'])) ? $_POST['email_id']:"";
        $category = (isset($_POST['category'])) ? $_POST['category']:"";
        $participate_address = (isset($_POST['participate_address'])) ? $_POST['participate_address']:"";
        
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK){		
		// get details of the uploaded file
		$fileTmpPath = $_FILES['file']['tmp_name'];
		$fileName = $_FILES['file']['name'];
		$fileSize = $_FILES['file']['size'];
		$fileType = $_FILES['file']['type'];
		$fileNameCmps = explode(".", $fileName);
		$fileExtension = strtolower(end($fileNameCmps));
	 
		// sanitize file-name
		$newFileName = md5(time() . $fileName) . '.' . $fileExtension;
	 
		  if(empty($errors)==true){
			  $uploadFileDir = './uploaded_files/';
			  $dest_path = $uploadFileDir . $newFileName;
			 if(move_uploaded_file($fileTmpPath, $dest_path)) 
			  {
			  }
			  else
			  {
				$errors[]='something went wrong.';
			  }
		  
		  }
	  }
	  else
	  {
		$errors[] ='Error:' . $_FILES['file']['error'];
	  }

      $image = $newFileName;
      if($obj->check_mobile_exist($mobile_no) == 0){
        if($obj->check_email_exist($email_id) == 0){
            $msg = $obj->ParticipateName($participate_name,$mobile_no,$email_id,$category,$participate_address,$image);
        }else{
            $msg = '<div class="alert alert-danger" role="alert">Your email address is already registered.</div>';
        }
    }else{
        $msg = '<div class="alert alert-danger" role="alert">Your mobile number is already registered.</div>';
   }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo TITLE;?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,500,600,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/bootstrap.min.css?v=<?php echo rand(1000,10000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/all.min.css?v=<?php echo rand(100,1000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/owl.carousel.min.css?v=<?php echo rand(100000,1000000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/tp-animation.css?v=<?php echo rand(10,100); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/style.css?v=<?php echo rand(100000,1000000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/responsive.css?v=<?php echo rand(1000,10000); ?>" media="all">    
</head>
<style>
    body  {
        background-image: url("http://localhost/narendra/Swachh_Bhopal_Competitions/images/base.png");
        background-repeat: no-repeat;
        }
</style>
<body>
    <header class="tp-main-menu header-menu-1 sticky-header">
        <!-- top logo/contac inf -->
        <div class="container">
            <div class="row row_menu_1">
                <div class="col-lg-6 col-md-6 col-12 col-logo-3">
                  
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <nav class="tp-menu tagpoint-menu-2">
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <img src="<?php echo BASE_URL; ?>/images/1.png">
    <section class="dropex-section faq-section" style="padding-top: 2em;">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-12">
                    <div class="section-head">
                        <img src="images/04.png" class="img-responsive">
                    </div> 
                </div>
				<div class="col-lg-7 col-md-12 col-12">
                    <div class="wrap_callbak">
                       <div class="row">
                            <div class="col-sm-4">&nbsp;</div>
                            <div class="col-sm-4"><?php if(isset($msg)){echo $msg;}?></div>
                            <div class="col-sm-4">&nbsp;</div>
                        </div>
                    <form class="tp-form-1" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-12" style="margin-bottom: 2em;">
                                    <p class="tp-form-el">
                                    <label for="formFileMultiple" class="form-label" style="font-weight: 800;">Enter Your Full name</label>
									<input type="text" name="participate_name" class="tp-user-name" placeholder="Name" required>
                                    </p>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                    <p class="tp-form-el">
                                    <label for="formFileMultiple" class="form-label" style="font-weight: 800;">Enter Your Mobile number</label>
                                       <input type="text" maxlength="10" minlength="10" name="mobile_no" class="tp-phone" placeholder="Phone / Mobile Number" required>
                                    </p>
                                </div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-12" style="margin-bottom: 2em;">
                                    <p class="tp-form-el">
                                    <label for="formFileMultiple" class="form-label" style="font-weight: 800;">Enter Your Email I'd</label>
									<input type="email" maxlength="100" name="email_id" class="tp-phone" placeholder="Email ID" required>
                                    </p>
                                </div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                    <p class="tp-form-el">
                                    <label for="formFileMultiple" class="form-label" style="font-weight: 800;">Please Select Category</label>
                                        <select name="category" class="tp-phone" required> 
                                            <option value="">Select Category</option>
                                            <option value="Painting">Painting</option>                                                    
                                            <option value="Wall_paint_mural">Wall paint / mural</option>                                                    
                                            <option value="Short_movie">Short movie</option>                                                    
                                            <option value="Slogan_writing">Slogan writing</option>                                                    
                                        </select>
								    </p>
                                </div>								
								<div class="col-lg-6 col-md-6 col-sm-6 col-12" style="margin-bottom: 2em;" >
                                    <p class="tp-form-el">
                                    <label for="formFileMultiple" class="form-label" style="font-weight: 800;">Enter Your Full Address</label>
								    <input type="text" maxlength="100" name="participate_address" class="tp-phone" placeholder="Address" required>
								  </p>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-12" style="margin-bottom: 2em;" >
                                <label for="formFileMultiple" class="form-label" style="font-weight: 800;">Please Upload image</label>
                                <input class="form-control" type="file" name="file" required/>
                                </div>
								<div class="col-12 ">
                                    <div class="tp-wrap-btn" style="text-align: center;">
                                        <button type="submit" name="submit" value="Submit" class="sendmessage_btn dropex-btn"> Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </section> 
    <script src="<?php echo BASE_URL ?>js/jquery.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/owl.carousel.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/odometer.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/progressbar.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/masonary.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/multipleFilterMasonry.js"></script>
    <script src="<?php echo BASE_URL ?>js/light-box.js"></script>
    <script src="<?php echo BASE_URL ?>js/noframework.waypoints.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/index.js"></script>
</div>
</body>
</html>